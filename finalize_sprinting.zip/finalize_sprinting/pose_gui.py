import sys
import os
import pandas as pd
import cv2
from PyQt6.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QPushButton, QLabel, QFileDialog,
    QMessageBox, QTableWidget, QTableWidgetItem, QHBoxLayout, QHeaderView,
    QScrollArea, QProgressBar, QTextEdit, QMainWindow, QFrame
)
from PyQt6.QtGui import QPixmap, QImage
from PyQt6.QtCore import Qt, QThread, pyqtSignal

# === Import your analyzer pipeline ===
from analizer_hybrid import run_full_pipeline  # <-- replace with your actual filename


# ========================
# Background Worker Thread
# ========================
class PipelineThread(QThread):
    progress = pyqtSignal(str)
    finished = pyqtSignal(str)

    def __init__(self, video_path):
        super().__init__()
        self.video_path = video_path

    def run(self):
        try:
            self.progress.emit("[INFO] Running full pipeline...")
            # Replace global variable in your script dynamically
            import analizer_hybrid as analyzer
            analyzer.INPUT_VIDEO = self.video_path
            analyzer.run_full_pipeline()
            self.finished.emit("✅ Analysis complete! best_pose_angles_summary.csv generated.")
        except Exception as e:
            self.finished.emit(f"[ERROR] {str(e)}")


# ========================
# Main GUI Class
# ========================
class SprintingPoseAnalyzer(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("Sprinting Pose Analyzer")
        self.setGeometry(200, 100, 1100, 700)
        self.video_path = None

        # --- Main Layout ---
        main_widget = QWidget()
        self.setCentralWidget(main_widget)
        self.layout = QVBoxLayout(main_widget)

        # --- Buttons Row ---
        btn_layout = QHBoxLayout()
        self.btn_upload = QPushButton("Upload Video")
        self.btn_analyze = QPushButton("Analyze Video")
        self.btn_view = QPushButton("View Runner Full Sprint")

        for btn in [self.btn_upload, self.btn_analyze, self.btn_view]:
            btn.setStyleSheet("""
                QPushButton {
                    background-color: #00b4d8;
                    color: white;
                    font-size: 16px;
                    font-weight: bold;
                    border-radius: 8px;
                    padding: 8px 16px;
                }
                QPushButton:hover { background-color: #0096c7; }
            """)
            btn.setCursor(Qt.CursorShape.PointingHandCursor)
            btn_layout.addWidget(btn)

        self.layout.addLayout(btn_layout)

        # --- Text Log Area ---
        self.log_area = QTextEdit()
        self.log_area.setReadOnly(True)
        self.log_area.setStyleSheet("background-color: #121212; color: #00ffcc; font-family: Consolas;")
        self.layout.addWidget(self.log_area)

        # --- Results Table ---
        self.table = QTableWidget()
        self.table.setStyleSheet("background-color: #1a1a1a; color: white;")
       

        # --- Connections ---
        self.btn_upload.clicked.connect(self.upload_video)
        self.btn_analyze.clicked.connect(self.run_pipeline)
        self.btn_view.clicked.connect(self.view_full_sprint)

        self.setStyleSheet("background-color: #0d0d0d; color: white;")

    # ------------------------
    # Upload Video Function
    # ------------------------
    def upload_video(self):
        file, _ = QFileDialog.getOpenFileName(
            self, "Select Sprinting Video", "", "Video Files (*.mp4 *.MOV *.avi)"
        )
        if file:
            self.video_path = file
            QMessageBox.information(self, "Upload Successful", f"Video uploaded:\n{file}")

    # ------------------------
    # Run Pipeline Function
    # ------------------------
    def run_pipeline(self):
        if not self.video_path:
            QMessageBox.warning(self, "No Video", "Please upload a video first.")
            return

        self.log_area.append("🚀 Starting full pipeline...")
        self.thread = PipelineThread(self.video_path)
        self.thread.progress.connect(self.log_area.append)
        self.thread.finished.connect(self.on_pipeline_done)
        self.thread.start()

    def on_pipeline_done(self, msg):
        self.log_area.append(msg)
        if os.path.exists("best_pose_angles_summary.csv"):
            self.display_results("best_pose_angles_summary.csv")
        else:
            QMessageBox.warning(self, "Missing Output", "best_pose_angles_summary.csv not found!")

    # ------------------------
    # Display CSV Results
    # ------------------------
    def display_results(self, csv_path):
        df = pd.read_csv(csv_path)

        # --- Clear layout first ---
        for i in reversed(range(self.layout.count())):
            item = self.layout.itemAt(i)
            widget = item.widget()
            if widget and isinstance(widget, QScrollArea):
                widget.deleteLater()

        # --- Scroll area for horizontal cards ---

        scroll = QScrollArea()
        scroll.setMinimumHeight(900)  # fills more of the window
        
        scroll.setWidgetResizable(True)
        scroll.setStyleSheet("background-color: #0a0a0a; border: none;")

        container = QWidget()
        h_layout = QHBoxLayout(container)
        h_layout.setContentsMargins(20, 20, 20, 20)
        h_layout.setSpacing(25)

        for _, row in df.iterrows():
            frame = QFrame()
            frame.setFixedSize(420, 720)
            frame.setStyleSheet("""
                QFrame {
                    background-color: #121212;
                    border-radius: 15px;
                    border: 1px solid #00b4d8;
                }
                QLabel {
                    color: white;
                    font-family: 'Segoe UI';
                }
            """)

            vbox = QVBoxLayout(frame)
            vbox.setAlignment(Qt.AlignmentFlag.AlignTop)

            # --- Pose Image ---
            img_path = row.get("IMAGE_PATH", "")
            img_label = QLabel()
            img_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
            if os.path.exists(img_path):
                pix = QPixmap(img_path).scaled(300, 220, Qt.AspectRatioMode.KeepAspectRatio,
                                               Qt.TransformationMode.SmoothTransformation)
                img_label.setPixmap(pix)
            else:
                img_label.setText("No Image")

            # --- Pose Name + Confidence ---
            pose = row.get("POSE", "Unknown")
            conf = row.get("CONFIDENCE", 0)
            header = QLabel(f"<b><span style='color:#00e0ff;font-size:18px;'>{pose}</span></b><br>"
                            f"<span style='color:#9ef01a;font-size:14px;'>Confidence: {conf}%</span>")
            header.setAlignment(Qt.AlignmentFlag.AlignCenter)

            vbox.addWidget(img_label)
            vbox.addWidget(header)


            # --- Angles Section ---
            for col in df.columns:
                if col in ["POSE", "CONFIDENCE", "IMAGE_PATH"]:
                    continue

                val = row[col]

                lbl = QLabel(f"{col.replace('_',' ')}: <b>{val}</b>")
                lbl.setStyleSheet("font-size:13px; color:#b0b0b0; margin-left:10px;")
                vbox.addWidget(lbl)

                

            h_layout.addWidget(frame)

        scroll.setWidget(container)
        self.layout.addWidget(scroll)
        self.log_area.append("✅ Fancy horizontal result cards loaded successfully.")

    # ------------------------
    # View Runner Full Sprint
    # ------------------------
    def view_full_sprint(self):
        folder = "pose_clean_full_skeleton_black"
        csv_path = "pose_angles_from_kalman.csv"

        if not os.path.isdir(folder):
            QMessageBox.warning(self, "No Frames Found",
                                "Run analysis first to generate skeleton frames.")
            return

        if not os.path.exists(csv_path):
            QMessageBox.warning(self, "Missing CSV",
                                "pose_angles_from_kalman.csv not found.")
            return

        # Load CSV
        df = pd.read_csv(csv_path)

        # Ensure ordered by FRAME
        if "FRAME_NAME" not in df.columns:
            QMessageBox.warning(self, "CSV Error", "CSV missing 'FRAME' column.")
            return

        df = df.sort_values("FRAME_NAME").reset_index(drop=True)

        # Detect angle columns (everything except FRAME)
        angle_columns = [c for c in df.columns if c != "FRAME_NAME"]

        win = QWidget()
        win.setWindowTitle("Full Sprint Viewer — Angles per Frame_Number")

        layout = QVBoxLayout(win)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)

        inner = QWidget()
        inner_layout = QVBoxLayout(inner)

        # Load images
        images = sorted([f for f in os.listdir(folder) if f.endswith(".png")])

        for img_file in images:
            # Extract frame number from filename
            try:
                frame_no = int(os.path.splitext(img_file)[0].split("_")[-1])
            except:
                continue

            # Check frame exists in CSV
            if frame_no >= len(df):
                continue

            row = df.iloc[frame_no]

            # === Card Frame ===
            card = QFrame()
            card.setStyleSheet("""
                QFrame {
                    background-color:#121212;
                    border: 1px solid #00b4d8;
                    border-radius: 14px;
                }
                QLabel { color: white; font-size: 13px; }
            """)
            card_layout = QVBoxLayout(card)

            # === Image ===
            img_path = os.path.join(folder, img_file)
            pix = QPixmap(img_path).scaled(
                320, 320,
                Qt.AspectRatioMode.KeepAspectRatio,
                Qt.TransformationMode.SmoothTransformation
            )
            img_lbl = QLabel()
            img_lbl.setPixmap(pix)
            img_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
            card_layout.addWidget(img_lbl)

            # === Highlight FRAME number ===
            frame_lbl = QLabel(
                f"<span style='font-size:18px; font-weight:bold; color:#FFD700;'>FRAME: {frame_no}</span>"
            )
            frame_lbl.setAlignment(Qt.AlignmentFlag.AlignCenter)
            card_layout.addWidget(frame_lbl)

            # === Add angles below ===
            for col in angle_columns:
                val = row[col]
                angle_lbl = QLabel(f"{col.replace('_',' ')}: <b>{val}</b>")
                angle_lbl.setStyleSheet("color:#cccccc; margin-left:10px;")
                card_layout.addWidget(angle_lbl)

            inner_layout.addWidget(card)

        scroll.setWidget(inner)
        layout.addWidget(scroll)

        win.resize(900, 800)
        win.show()
        self.full_sprint_window = win



# ========================
# Run GUI
# ========================
if __name__ == "__main__":
    app = QApplication(sys.argv)
    gui = SprintingPoseAnalyzer()
    gui.show()
    sys.exit(app.exec())
