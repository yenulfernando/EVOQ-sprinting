import sys
import os
import pandas as pd
from PyQt6.QtWidgets import (
    QApplication, QWidget, QVBoxLayout, QPushButton, QLabel, QFileDialog,
    QMessageBox, QHBoxLayout, QScrollArea, QFrame, QComboBox, QMainWindow
)
from PyQt6.QtGui import QPixmap, QFont
from PyQt6.QtCore import Qt, QThread, pyqtSignal

# ============================
# IMPORT YOUR VELOCITY PIPELINE
# ============================
from speed3 import main as run_velocity_pipeline


# ============================
# Worker Thread
# ============================
class PipelineThread(QThread):
    finished = pyqtSignal(str)

    def __init__(self, video_path, run_direction):
        super().__init__()
        self.video_path = video_path
        self.run_direction = run_direction

    def run(self):
        try:
            import speed3 as V
            V.VIDEO_PATH = self.video_path
            V.RUN_DIRECTION = self.run_direction
            V.main()
            self.finished.emit("✅ Velocity analysis completed.")
        except Exception as e:
            self.finished.emit(f"[ERROR] {e}")


# ============================
# Professional GUI
# ============================
class VelocityGUI(QMainWindow):
    def __init__(self):
        super().__init__()

        self.setWindowTitle("Sprinter Velocity Analyzer")
        self.setGeometry(150, 40, 1500, 950)

        # Main widget
        main = QWidget()
        self.setCentralWidget(main)
        self.layout = QVBoxLayout(main)

        # ==========================================
        # Elegant Title Bar
        # ==========================================
        title = QLabel("🏃‍♂️ Sprinter Velocity Analyzer")
        title.setAlignment(Qt.AlignmentFlag.AlignCenter)
        title.setStyleSheet("""
            font-size: 34px;
            font-weight: bold;
            color: #00d4ff;
            padding: 15px;
        """)
        self.layout.addWidget(title)

        # ==========================================
        # Top Options Bar
        # ==========================================
        options_bar = QHBoxLayout()
        options_bar.setSpacing(20)

        # Upload button
        self.btn_upload = QPushButton("Upload Video")
        self.btn_upload.clicked.connect(self.upload_video)

        # Run direction selector
        self.combo_dir = QComboBox()
        self.combo_dir.addItems(["L2R", "R2L"])
        self.combo_dir.setFixedWidth(150)
        self.combo_dir.setStyleSheet("""
            QComboBox {
                background: #1e1e1e; color: white;
                padding: 6px;
                font-size: 16px;
                border: 2px solid #00b4d8;
                border-radius: 8px;
            }
        """)

        # Run button
        self.btn_run = QPushButton("Measure Velocity")
        self.btn_run.clicked.connect(self.run_pipeline)

        # Style both buttons
        for btn in [self.btn_upload, self.btn_run]:
            btn.setStyleSheet("""
                QPushButton {
                    background-color:#00b4d8;
                    color:white; font-size:18px;
                    padding:10px 25px; border-radius:10px;
                }
                QPushButton:hover { background-color:#009ac2; }
            """)

        options_bar.addWidget(self.btn_upload)
        options_bar.addWidget(self.combo_dir)
        options_bar.addWidget(self.btn_run)

        self.layout.addLayout(options_bar)

        # Holder for results
        self.results_area = None
        self.video_path = None

    # ============================
    def upload_video(self):
        file, _ = QFileDialog.getOpenFileName(
            self, "Select Sprint Video", "", "Video Files (*.mp4 *.MOV *.avi)"
        )
        if file:
            self.video_path = file
            QMessageBox.information(self, "Uploaded", f"Selected:\n{file}")

    # ============================
    def run_pipeline(self):
        if not self.video_path:
            QMessageBox.warning(self, "No Video", "Please upload a video first.")
            return

        run_dir = self.combo_dir.currentText()

        self.thread = PipelineThread(self.video_path, run_dir)
        self.thread.finished.connect(self.pipeline_done)
        self.thread.start()

        QMessageBox.information(self, "Processing", "Velocity pipeline is running...")

    # ============================
    def pipeline_done(self, msg):
        QMessageBox.information(self, "Done", msg)
        if os.path.exists("sprinter_splits.csv"):
            self.display_results("sprinter_splits.csv")
        else:
            QMessageBox.warning(self, "Missing File", "sprinter_splits.csv not found.")

    # ============================
    def display_results(self, csv_path):
        df = pd.read_csv(csv_path)

        if self.results_area:
            self.results_area.deleteLater()

        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setStyleSheet("background-color:#0e0e0e; border:none;")
        self.results_area = scroll
        self.layout.addWidget(scroll)

        container = QWidget()
        h = QHBoxLayout(container)
        h.setContentsMargins(30, 30, 30, 30)
        h.setSpacing(40)

        # Load runner thumbnail
        runner_img = "assets/runner.png"
        if os.path.exists(runner_img):
            runner_pix = QPixmap(runner_img).scaled(
                260, 260,
                Qt.AspectRatioMode.KeepAspectRatio,
                Qt.TransformationMode.SmoothTransformation
            )
        else:
            runner_pix = None

        # ----------------------
        # Create a card per row
        # ----------------------
        for _, row in df.iterrows():

            card = QFrame()
            card.setFixedSize(450, 650)
            card.setStyleSheet("""
                QFrame {
                    background-color:#151515;
                    border: 2px solid #00b4d8;
                    border-radius: 18px;
                }
                QLabel { color:white; }
            """)

            v = QVBoxLayout(card)
            v.setAlignment(Qt.AlignmentFlag.AlignTop)
            v.setContentsMargins(20, 20, 20, 20)
            v.setSpacing(12)

            # Sprinter Image
            img_label = QLabel()
            img_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
            if runner_pix:
                img_label.setPixmap(runner_pix)
            else:
                img_label.setText("Runner Image\nNot Found")
                img_label.setStyleSheet("font-size:16px; color: #888;")
            v.addWidget(img_label)

            # Time + Speed (main focus)
            time_s = row["time_s"]
            speed_m_s = row["speed_m_s"]

            highlight = QLabel(
                f"<b><span style='font-size:28px; color:#9ef01a;'>{speed_m_s:.2f} m/s</span></b><br>"
                f"<span style='font-size:22px; color:#00e0ff;'>Time: {time_s:.2f} s</span>"
            )
            highlight.setAlignment(Qt.AlignmentFlag.AlignCenter)
            v.addWidget(highlight)

            # Divider
            divider = QFrame()
            divider.setFrameShape(QFrame.Shape.HLine)
            divider.setStyleSheet("color:#00b4d8;")
            v.addWidget(divider)

            # Additional details (if needed)
            for col in df.columns:
                if col in ["time_s", "speed_m_s"]:
                    continue
                val = row[col]
                txt = QLabel(f"{col}: <b>{val}</b>")
                txt.setStyleSheet("font-size:15px; color:#ccc;")
                v.addWidget(txt)

            h.addWidget(card)

        scroll.setWidget(container)


# ============================
if __name__ == "__main__":
    app = QApplication(sys.argv)
    gui = VelocityGUI()
    gui.show()
    sys.exit(app.exec())
